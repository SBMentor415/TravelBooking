# TravelBooking (Android, Java)

## Open in VS Code
1. Unzip and open the `TravelBooking` folder in VS Code (File → Open Folder).
2. Recommended extensions: "Extension Pack for Java" and "Gradle for Java".
3. You need: JDK 17, the Android SDK (API 34), and `ANDROID_HOME` set
   (or create `local.properties` with `sdk.dir=/path/to/Android/Sdk`).

## Build & run from the VS Code terminal
First time only, create the Gradle wrapper (needs Gradle installed once):
```
gradle wrapper --gradle-version 8.2
```
Then:
```
./gradlew assembleDebug          # Windows: gradlew.bat assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```
Start an emulator first (`emulator -avd <name>`) or plug in a device.

## Structure
```
app/src/main/java/com/example/travelbooking/
    MainActivity.java     login screen (name + phone)
    BookingForm.java      spinners + date pickers
    TravelDetails.java    shows booking, BACK / LOGOUT
app/src/main/res/layout/
    activity_main.xml           RelativeLayout
    activity_booking_form.xml   LinearLayout
    activity_travel_details.xml ConstraintLayout
app/src/main/res/values/arrays.xml   destinations + travelers
```
