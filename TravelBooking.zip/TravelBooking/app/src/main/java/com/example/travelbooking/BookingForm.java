package com.example.travelbooking;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class BookingForm extends AppCompatActivity {

    private Spinner SpinnerDestination;
    private EditText EditTextDeparture;
    private EditText EditTextReturn;
    private Spinner SpinnerTravelers;
    private Button ButtonBookTravel;

    private String name;
    private String phone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_form);

        SpinnerDestination = findViewById(R.id.SpinnerDestination);
        EditTextDeparture = findViewById(R.id.EditTextDeparture);
        EditTextReturn = findViewById(R.id.EditTextReturn);
        SpinnerTravelers = findViewById(R.id.SpinnerTravelers);
        ButtonBookTravel = findViewById(R.id.ButtonBookTravel);

        name = getIntent().getStringExtra("name");
        phone = getIntent().getStringExtra("phone");

        // Spinners
        ArrayAdapter<CharSequence> destinationAdapter = ArrayAdapter.createFromResource(
                this, R.array.destinations, android.R.layout.simple_spinner_item);
        destinationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        SpinnerDestination.setAdapter(destinationAdapter);

        ArrayAdapter<CharSequence> travelersAdapter = ArrayAdapter.createFromResource(
                this, R.array.travelers, android.R.layout.simple_spinner_item);
        travelersAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        SpinnerTravelers.setAdapter(travelersAdapter);

        // Date pickers
        EditTextDeparture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePicker(EditTextDeparture);
            }
        });

        EditTextReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePicker(EditTextReturn);
            }
        });

        // Book travel
        ButtonBookTravel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String destination = SpinnerDestination.getSelectedItem().toString();
                String departure = EditTextDeparture.getText().toString();
                String returnDate = EditTextReturn.getText().toString();
                String travelers = SpinnerTravelers.getSelectedItem().toString();

                if (SpinnerDestination.getSelectedItemPosition() == 0
                        || SpinnerTravelers.getSelectedItemPosition() == 0
                        || departure.isEmpty() || returnDate.isEmpty()) {
                    Toast.makeText(BookingForm.this,
                            "Please fill in all details", Toast.LENGTH_SHORT).show();
                    return;
                }

                Intent intent = new Intent(BookingForm.this, TravelDetails.class);
                intent.putExtra("name", name);
                intent.putExtra("phone", phone);
                intent.putExtra("destination", destination);
                intent.putExtra("departure", departure);
                intent.putExtra("return", returnDate);
                intent.putExtra("travelers", travelers);
                startActivity(intent);
            }
        });
    }

    private void showDatePicker(final EditText target) {
        Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int y, int m, int d) {
                        target.setText(d + "/" + (m + 1) + "/" + y);
                    }
                }, year, month, day);
        dialog.show();
    }
}
