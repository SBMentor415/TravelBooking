package com.example.travelbooking;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class TravelDetails extends AppCompatActivity {

    private TextView TextViewBookingDetails;
    private Button ButtonLogout;
    private Button ButtonBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_travel_details);

        TextViewBookingDetails = findViewById(R.id.TextViewBookingDetails);
        ButtonLogout = findViewById(R.id.ButtonLogout);
        ButtonBack = findViewById(R.id.ButtonBack);

        Intent intent = getIntent();
        final String name = intent.getStringExtra("name");
        final String phone = intent.getStringExtra("phone");
        String destination = intent.getStringExtra("destination");
        String departure = intent.getStringExtra("departure");
        String returnDate = intent.getStringExtra("return");
        String travelers = intent.getStringExtra("travelers");

        String details = "Booking Details\n\n"
                + "Name: " + name + "\n"
                + "Phone: " + phone + "\n"
                + "Destination: " + destination + "\n"
                + "Departure Date: " + departure + "\n"
                + "Return Date: " + returnDate + "\n"
                + "Number of Travelers: " + travelers;

        TextViewBookingDetails.setText(details);

        ButtonLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();   // closes all activities -> exits the app
            }
        });

        ButtonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent back = new Intent(TravelDetails.this, BookingForm.class);
                back.putExtra("name", name);
                back.putExtra("phone", phone);
                back.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(back);
                finish();
            }
        });
    }
}
